<?php
if ( ! defined('ABSPATH') ) exit;

add_action('admin_menu', function () {
    add_menu_page(
        __('Global Phone Field', 'global-phone-field'), // Page title
        __('Phone Field', 'global-phone-field'),        // Menu title
        'manage_options',                               // Capability
        'gpf-settings',                                 // Slug
        'gpf_render_settings_page',                     // Callback
        'dashicons-phone',                              // Icon
        60                                              // Position
    );
});


function gpf_render_settings_page() {
    if ( ! current_user_can('manage_options') ) {
        return;
    }

    // Save
    if ( isset($_POST['gpf_save_settings']) && check_admin_referer('gpf_save', 'gpf_nonce') ) {
        $country = isset($_POST['gpf_default_country']) ? sanitize_text_field($_POST['gpf_default_country']) : 'pk';
        if (strlen($country) !== 2) {
            $country = 'pk'; // fallback to 2-letter ISO
        }
        update_option('gpf_default_country', strtolower($country));
        echo '<div class="updated notice"><p>' . esc_html__('Settings saved.', 'global-phone-field') . '</p></div>';
    }

    $default = get_option('gpf_default_country', 'pk');
    ?>
    <div class="wrap">
        <h1><?php esc_html_e('Global Phone Field Settings', 'global-phone-field'); ?></h1>
        <form method="post">
            <?php wp_nonce_field('gpf_save', 'gpf_nonce'); ?>
            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row">
                        <label for="gpf_default_country"><?php esc_html_e('Default Country', 'global-phone-field'); ?></label>
                    </th>
                    <td>
                        <input type="text"
                               id="gpf_default_country"
                               name="gpf_default_country"
                               value="<?php echo esc_attr($default); ?>"
                               class="regular-text"
                               placeholder="e.g. pk, us, in" />
                        <p class="description">
                            <?php esc_html_e('Use 2-letter ISO country code (lowercase). Example: pk, us, in, gb, sa, ae', 'global-phone-field'); ?>
                        </p>
                    </td>
                </tr>
            </table>

            <p class="submit">
                <button type="submit" name="gpf_save_settings" class="button button-primary">
                    <?php esc_html_e('Save Changes', 'global-phone-field'); ?>
                </button>
            </p>
        </form>

        <hr />

        <h2><?php esc_html_e('How to Use', 'global-phone-field'); ?></h2>
        <ol style="margin-left:18px;">
            <li><?php esc_html_e('Set your Default Country above (e.g., pk).', 'global-phone-field'); ?></li>
            <li><?php esc_html_e('Insert the shortcode into any page/form area:', 'global-phone-field'); ?>
                <code>[global_phone_field required="true" name="phone" full_hidden="phone_full"]</code>
            </li>
            <li><?php esc_html_e('On submit, read the hidden field for full E.164 number (e.g., +923001234567).', 'global-phone-field'); ?></li>
        </ol>
    </div>
    <?php
}
