<?php
/**
 * Plugin Name: Global Phone Field
 * Description: International phone input with flags & country codes. Use shortcode [global_phone_field] in any form/page. Set default country in Settings → Global Phone Field.
 * Version: 1.0.0
 * Author: Talha Ghaffar
 * License: GPL2+
 * Text Domain: global-phone-field
 */

if ( ! defined('ABSPATH') ) exit;

define('GPF_VER', '1.0.0');
define('GPF_DIR', plugin_dir_path(__FILE__));
define('GPF_URL', plugin_dir_url(__FILE__));

/**
 * Activate: set default country if not set
 */
register_activation_hook(__FILE__, function () {
    if (! get_option('gpf_default_country')) {
        // Default to Pakistan
        update_option('gpf_default_country', 'pk');
    }
});

/**
 * Admin notice right after activation to guide setting
 */
add_action('admin_notices', function () {
    if ( get_transient('gpf_show_settings_notice') ) {
        ?>
        <div class="notice notice-success is-dismissible">
            <p><?php echo esc_html__('Global Phone Field activated! Set your default country here:', 'global-phone-field'); ?>
                <a href="<?php echo esc_url(admin_url('options-general.php?page=gpf-settings')); ?>"><?php esc_html_e('Open Settings', 'global-phone-field'); ?></a>
            </p>
        </div>
        <?php
        delete_transient('gpf_show_settings_notice');
    }
});
register_activation_hook(__FILE__, function(){
    set_transient('gpf_show_settings_notice', 1, 30);
});

/**
 * Enqueue scripts/styles (frontend only)
 * - intl-tel-input via CDN
 * - our init JS & CSS
 */
add_action('wp_enqueue_scripts', function () {
    // intl-tel-input CSS & JS (CDN)
    wp_enqueue_style(
        'gpf-iti',
        'https://cdn.jsdelivr.net/npm/intl-tel-input@19.5.6/build/css/intlTelInput.css',
        [],
        '19.5.6'
    );

    wp_enqueue_script(
        'gpf-iti',
        'https://cdn.jsdelivr.net/npm/intl-tel-input@19.5.6/build/js/intlTelInput.min.js',
        [],
        '19.5.6',
        true
    );

    // utils (for formatting, validation)
    wp_enqueue_script(
        'gpf-iti-utils',
        'https://cdn.jsdelivr.net/npm/intl-tel-input@19.5.6/build/js/utils.js',
        ['gpf-iti'],
        '19.5.6',
        true
    );

    // our CSS
    wp_enqueue_style('gpf-css', GPF_URL . 'assets/css/gpf.css', [], GPF_VER);

    // our init JS
    wp_enqueue_script('gpf-init', GPF_URL . 'assets/js/gpf-init.js', ['gpf-iti', 'gpf-iti-utils'], GPF_VER, true);

    // pass PHP → JS
    $default_country = get_option('gpf_default_country', 'pk');
    wp_localize_script('gpf-init', 'gpfSettings', [
        'defaultCountry' => $default_country ?: 'pk',
    ]);
});

/**
 * Shortcode: [global_phone_field]
 * Attributes:
 * - name: input name (default "phone")
 * - placeholder: placeholder text
 * - required: "true" / "false"
 * - full_hidden: hidden field name to receive full E.164 (default "phone_full")
 */
add_shortcode('global_phone_field', function ($atts) {
    $atts = shortcode_atts([
        'name'        => 'phone',
        'placeholder' => 'Enter phone number',
        'required'    => 'false',
        'full_hidden' => 'phone_full',
        'id'          => '', // allow multiple fields: pass custom id
    ], $atts, 'global_phone_field');

    $id = $atts['id'] ? sanitize_html_class($atts['id']) : 'gpf_phone_' . wp_rand(1000, 999999);
    $name = sanitize_key($atts['name']);
    $full_hidden = sanitize_key($atts['full_hidden']);
    $placeholder = esc_attr($atts['placeholder']);
    $required = ( $atts['required'] === 'true' ) ? 'required' : '';

    ob_start();
    ?>
    <div class="gpf-wrap">
        <input id="<?php echo esc_attr($id); ?>"
               type="tel"
               class="gpf-phone-field"
               name="<?php echo esc_attr($name); ?>"
               placeholder="<?php echo $placeholder; ?>"
               <?php echo $required; ?>
               inputmode="tel"
               autocomplete="tel" />

        <input type="hidden" class="gpf-full-output" name="<?php echo esc_attr($full_hidden); ?>" value="" />
        <div class="gpf-error" aria-live="polite"></div>
    </div>
    <?php
    return ob_get_clean();
});

/**
 * Admin settings page
 */
require_once GPF_DIR . 'includes/settings-page.php';
