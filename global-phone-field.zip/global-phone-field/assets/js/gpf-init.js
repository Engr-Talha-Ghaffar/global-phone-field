(function(){
    function initGPFField(input) {
        if (!input || input.classList.contains('gpf-processed')) return;

        input.classList.add('gpf-processed');

        // Create hidden field for full number
        var hidden = document.createElement('input');
        hidden.type = 'hidden';
        hidden.name = input.name + '_full';
        input.parentNode.insertBefore(hidden, input.nextSibling);

        var iti = window.intlTelInput(input, {
            initialCountry: (window.gpfSettings && gpfSettings.defaultCountry) ? gpfSettings.defaultCountry : 'pk',
            separateDialCode: true,
            nationalMode: false
        });

        function setHidden() {
            hidden.value = iti.getNumber() || '';
        }

        ['keyup','change','countrychange','blur'].forEach(function(evt){
            input.addEventListener(evt, setHidden);
        });

        setHidden();
    }

    function ready(fn){document.readyState!=='loading'?fn():document.addEventListener('DOMContentLoaded',fn);}
    ready(function(){
        document.querySelectorAll('input[type="tel"]').forEach(initGPFField);
    });
})();
